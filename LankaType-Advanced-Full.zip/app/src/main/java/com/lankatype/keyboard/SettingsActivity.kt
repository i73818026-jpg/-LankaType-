package com.lankatype.keyboard
import android.app.Activity
import android.os.Bundle
import android.widget.*
class SettingsActivity:Activity(){
 private val p by lazy{getSharedPreferences("settings",MODE_PRIVATE)}
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24)}
  r.addView(TextView(this).apply{text=getString(R.string.settings_title);textSize=26f})
  r.addView(TextView(this).apply{text="Appearance";textSize=18f})
  r.addView(Switch(this).apply{text="Dark theme";isChecked=p.getBoolean("dark",true);setOnCheckedChangeListener{_,v->p.edit().putBoolean("dark",v).apply()}})
  r.addView(TextView(this).apply{text="Keyboard height";textSize=18f})
  val s=SeekBar(this).apply{max=30;progress=p.getInt("keyHeight",52)-40}
  r.addView(s);s.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(x:SeekBar?,v:Int,f:Boolean){p.edit().putInt("keyHeight",v+40).apply()};override fun onStartTrackingTouch(x:SeekBar?){ };override fun onStopTrackingTouch(x:SeekBar?){ }})
  r.addView(Button(this).apply{text="Open keyboard settings";setOnClickListener{startActivity(android.content.Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS))}})
  r.addView(Button(this).apply{text="Reset settings";setOnClickListener{p.edit().clear().apply();Toast.makeText(this@SettingsActivity,"Settings reset",Toast.LENGTH_SHORT).show()}})
  setContentView(r)
 }
}